import subprocess
import sys

def install_package(package_name):
    try:
        # Install the package using pip
        subprocess.check_call([sys.executable, "-m", "pip", "install", package_name])
        print(f"{package_name} has been installed successfully.")
    except subprocess.CalledProcessError as e:
        print(f"Failed to install {package_name}. Error: {e}")

if __name__ == "__main__":
    install_package("bcrypt")

