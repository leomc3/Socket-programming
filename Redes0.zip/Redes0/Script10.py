import socket
import ssl
import sqlite3
import threading
import uuid
import hashlib
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
import base64

# Caminhos para os arquivos de certificado e chave privada
CERT_FILE = "certificate.pem"
KEY_FILE = "private_key.pem"

# Dicionário para rastrear conexões de clientes e autenticação
clientes_conectados = {}
clientes_autenticados = {}

def encrypt_message(message, key):
    cipher = AES.new(key, AES.MODE_CBC)
    ct_bytes = cipher.encrypt(pad(message.encode(), AES.block_size))
    iv = base64.b64encode(cipher.iv).decode('utf-8')
    ct = base64.b64encode(ct_bytes).decode('utf-8')
    return iv + ct

def decrypt_message(encrypted_message, key):
    iv = base64.b64decode(encrypted_message[:24])
    ct = base64.b64decode(encrypted_message[24:])
    cipher = AES.new(key, AES.MODE_CBC, iv)
    pt = unpad(cipher.decrypt(ct), AES.block_size)
    return pt.decode('utf-8')

def authenticate_user(username, password):
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    
    hashed_password = hashlib.sha256(password.encode()).hexdigest()
    
    cursor.execute("SELECT password, secret_key FROM users WHERE username = ?", (username,))
    row = cursor.fetchone()
    
    conn.close()
    
    if row and row[0] == hashed_password:
        return row[1]  # Retorna a chave secreta se o login for bem-sucedido
    return None

def handle_client(client_ssl_socket, addr):
    client_id = str(uuid.uuid4())  # Gera um identificador único para o cliente
    clientes_conectados[client_id] = client_ssl_socket
    print(f"Cliente {client_id} conectado de {addr}")

    try:
        while True:
            data = client_ssl_socket.recv(1024)
            if not data:
                break

            mensagem = data.decode('utf-8')
            print(f"Recebido de {client_id}: {mensagem}")

            if mensagem.startswith("MSG"):
                parts = mensagem.split(' ', 2)
                if len(parts) < 3:
                    response = "Erro: Sintaxe inválida. Use: MSG client-id text ou MSG ALL text"
                else:
                    target = parts[1]
                    text = parts[2]
                    if target == "ALL":
                        for cid, conn in clientes_conectados.items():
                            if cid in clientes_autenticados:
                                key = clientes_autenticados[cid]
                                encrypted_text = encrypt_message(text, key)
                                conn.sendall(encrypted_text.encode())
                        response = "Mensagem enviada para todos os clientes"
                    else:
                        if target in clientes_conectados:
                            key = clientes_autenticados.get(target)
                            if key:
                                encrypted_text = encrypt_message(text, key)
                                clientes_conectados[target].sendall(encrypted_text.encode())
                                response = f"Mensagem enviada para {target}"
                            else:
                                response = f"Erro: Cliente {target} não autenticado"
                        else:
                            response = f"Erro: Cliente {target} não encontrado ou desconectado."
            elif mensagem.startswith("LOGIN"):
                parts = mensagem.split(' ', 2)
                if len(parts) != 3:
                    response = "Erro: Sintaxe inválida. Use: LOGIN username password"
                else:
                    username = parts[1]
                    password = parts[2]
                    secret_key = authenticate_user(username, password)
                    if secret_key:
                        clientes_autenticados[client_id] = secret_key
                        response = f"Login bem-sucedido para {username}"
                    else:
                        response = "Erro: Nome de usuário ou senha inválidos"
            elif mensagem.startswith("LOGOFF"):
                parts = mensagem.split(' ', 1)
                if len(parts) != 2:
                    response = "Erro: Sintaxe inválida. Use: LOGOFF client-id"
                else:
                    logoff_id = parts[1]
                    logoff_cliente(logoff_id)
                    response = f"Cliente {logoff_id} desconectado"
            else:
                response = "Comando não reconhecido"

            client_ssl_socket.sendall(response.encode('utf-8'))

    except Exception as e:
        print(f"Erro durante a comunicação com o cliente {addr}: {str(e)}")
    finally:
        if client_id in clientes_conectados:
            del clientes_conectados[client_id]
        if client_id in clientes_autenticados:
            del clientes_autenticados[client_id]
        client_ssl_socket.close()
        print(f"Cliente {client_id} desconectado")

def create_server():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind(('0.0.0.0', 1234))
    server_socket.listen(5)

    print("Servidor em execução na porta 1234...")

    context = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
    context.load_cert_chain(certfile=CERT_FILE, keyfile=KEY_FILE)

    ssl_server_socket = context.wrap_socket(server_socket, server_side=True)

    while True:
        client_ssl_socket, addr = ssl_server_socket.accept()
        threading.Thread(target=handle_client, args=(client_ssl_socket, addr)).start()

if __name__ == "__main__":
    create_server()
