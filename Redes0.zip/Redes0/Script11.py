import socket
import ssl
import hashlib

# Caminhos para os arquivos de certificado e chave privada
CERT_FILE = "certificate.pem"
KEY_FILE = "private_key.pem"

def create_client_socket(server_ip, server_port):
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    
    context = ssl.create_default_context(ssl.Purpose.SERVER_AUTH, cafile=CERT_FILE)
    ssl_client_socket = context.wrap_socket(client_socket, server_hostname=server_ip)
    
    ssl_client_socket.connect((server_ip, server_port))
    
    return ssl_client_socket

def encrypt_message(message, key):
    cipher = AES.new(key, AES.MODE_CBC)
    ct_bytes = cipher.encrypt(pad(message.encode(), AES.block_size))
    iv = base64.b64encode(cipher.iv).decode('utf-8')
    ct = base64.b64encode(ct_bytes).decode('utf-8')
    return iv + ct

def decrypt_message(encrypted_message, key):
    iv = base64.b64decode(encrypted_message[:24])
    ct = base64.b64decode(encrypted_message[24:])
    cipher = AES.new(key, AES.MODE_CBC, iv)
    pt = unpad(cipher.decrypt(ct), AES.block_size)
    return pt.decode('utf-8')

def send_message(socket, message):
    socket.sendall(message.encode('utf-8'))

def receive_message(socket):
    response = socket.recv(1024).decode('utf-8')
    return response

def main():
    server_ip = '127.0.0.1'  # IP do servidor
    server_port = 1234       # Porta do servidor
    
    client_socket = create_client_socket(server_ip, server_port)
    
    try:
        username = input("Digite o nome de usuário: ")
        password = input("Digite a senha: ")
        login_message = f"LOGIN {username} {password}"
        send_message(client_socket, login_message)
        response = receive_message(client_socket)
        print("Resposta do servidor:", response)
        
        # Após login bem-sucedido, a chave secreta deve ser usada
        if response.startswith("Login bem-sucedido"):
            while True:
                target = input("Digite o ID do cliente para enviar a mensagem (ou ALL para todos): ")
                text = input("Digite a mensagem: ")
                message = f"MSG {target} {text}"
                send_message(client_socket, message)
                response = receive_message(client_socket)
                print("Resposta do servidor:", response)
                if input("Deseja sair? (s/n): ") == 's':
                    break
        
        logoff_message = f"LOGOFF {username}"
        send_message(client_socket, logoff_message)
        response = receive_message(client_socket)
        print("Resposta do servidor:", response)
    
    finally:
        client_socket.close()

if __name__ == "__main__":
    main()
