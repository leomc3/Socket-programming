import socket
import ssl
import sqlite3
import threading
import uuid  # Para gerar identificadores únicos para clientes

# caminhos para os arquivos de certificado e chave privada
CERT_FILE = "certificate.pem"
KEY_FILE = "private_key.pem"

# Dicionário para rastrear conexões de clientes
clientes_conectados = {}

# Função para enviar mensagem para todos os clientes
def enviar_mensagem_para_todos(mensagem):
    for client_id, conn in clientes_conectados.items():
        try:
            conn.sendall(mensagem.encode())
        except Exception as e:
            print(f"Erro ao enviar mensagem para cliente {client_id}: {str(e)}")

# Enviar mensagem para um cliente específico
def enviar_mensagem_para_cliente(client_id, mensagem):
    if client_id in clientes_conectados:
        conn = clientes_conectados[client_id]
        conn.sendall(mensagem.encode())
    else:
        print(f"Cliente {client_id} não encontrado ou desconectado.")

def handle_client(client_ssl_socket, addr):
    try:
        print(f"Conexão de {addr}")

        # Conectar ao banco de dados (ou criar se não existir)
        conn = sqlite3.connect('users.db')
        cursor = conn.cursor()


        while True:
            # Recebe dados do cliente
            data = client_ssl_socket.recv(1024)
            if not data:
                break  # Se não houver dados, saia do loop

            print(f"Recebido: {data.decode('utf-8')}")

            # Exemplo de consulta SQL
            cursor.execute('SELECT username,password FROM users WHERE username = ?', ('bob',))
            row = cursor.fetchone()

            if row:
                # Construa a resposta como uma string
                response = f"Username: {row[0]}, Password: {row[1]}"
            else:
                response = "Usuário não encontrado"

            # Enviando uma resposta
            client_ssl_socket.sendall(response.encode('utf-8'))

    except Exception as e:
        print(f"Erro durante a comunicação com o cliente {addr}: {str(e)}")
    finally:
        # Fechar o cursor e o socket do cliente
        cursor.close()
        client_ssl_socket.close()
        # Fechar a conexão com o banco de dados
        conn.close()

def create_server():
    # Cria um socket
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind(('127.0.0.1', 1234))
    server_socket.listen(5)

    print("Servidor em execução na porta 1234...")

    # Configurar contexto SSL
    context = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
    context.load_cert_chain(certfile=CERT_FILE, keyfile=KEY_FILE)

    # Envolva o socket do servidor com SSL
    ssl_server_socket = context.wrap_socket(server_socket, server_side=True)

    #looping de conexão com thread
    while True:
        client_ssl_socket, addr = ssl_server_socket.accept()
        # Inicie uma nova thread para lidar com o cliente
        threading.Thread(target=handle_client, args=(client_ssl_socket, addr)).start()

if __name__ == "__main__":
    create_server()

