import sqlite3
import bcrypt

# Conectar ao banco de dados
conn = sqlite3.connect('users.db')
cursor = conn.cursor()

# Criar a tabela 'users'
cursor.execute('''
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL
)
''')

# Função para inserir um novo usuário com senha hash
def insert_user(username, password):
    hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
    try:
        cursor.execute('INSERT INTO users (username, password) VALUES (?, ?)', (username, hashed_password))
        conn.commit()
        print(f"Usuário {username} inserido com sucesso.")
    except sqlite3.IntegrityError:
        print(f"Erro: O usuário {username} já existe.")
        exit(1) #GALERA, substituir por um return, para não encerrar toda a aplicação

# Função para verificar a senha de um usuário
def verify_password(username, password):
    cursor.execute('SELECT username,password FROM users WHERE username = ?', (username,))
    row = cursor.fetchone()
    #print('teste:', row[0], row[1])
    if row and bcrypt.checkpw(password.encode('utf-8'), row[1]):
        return True
    return False

# Inserir alguns usuários (exemplo)
insert_user('alice', 'senha_alice')
insert_user('bob', 'senha_bob')

# Verificar senhas
print("Verificação de senha para 'alice':", verify_password('alice', 'senha_alice'))
print("Verificação de senha para 'bob':", verify_password('bob', 'senha_errada'))

# Fechar a conexão
conn.close()
