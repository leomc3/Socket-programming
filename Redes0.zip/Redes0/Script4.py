import socket
import ssl

CERT_FILE = 'server.crt'  # Caminho para o arquivo de certificado SSL
KEY_FILE = 'server.key'   # Caminho para o arquivo de chave privada SSL

def start_ssl_connection():
    # cria socket
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    print("Socket criado.")

    # Cria contexto SSL
    context = ssl.create_default_context()
    context.load_verify_locations('certificate.pem')  # Carrega o certificado autoassinado
    context.verify_mode = ssl.CERT_REQUIRED  # Requer verificação do certificado
    context.check_hostname = False

    ssl_client_socket = context.wrap_socket(client_socket, server_hostname='127.0.0.1')
    print("Socket envolvido com SSL.")

    print("Tentando conectar...")
    ssl_client_socket.connect(('127.0.0.1', 1234))
    print("Conectado ao servidor.")

    return ssl_client_socket

def communicate_with_server(ssl_client_socket, message):
    try:
        # Limpar o buffer do socket antes de enviar nova mensagem
        while ssl_client_socket.pending():
            ssl_client_socket.recv(ssl_client_socket.pending())

        # Enviando uma mensagem
        ssl_client_socket.sendall(message.encode('utf-8'))
        print(f"Mensagem enviada: {message}")

        # Recebendo a resposta
        data = ssl_client_socket.recv(1024)
        print(f"Recebido: {data.decode('utf-8')}")

    except Exception as e:
        print(f"Erro durante a comunicação com o servidor: {str(e)}")

def close_ssl_connection(ssl_client_socket):
    ssl_client_socket.close()
    print("Conexão fechada.")

def create_client():
    ssl_client_socket = start_ssl_connection()

    try:
        while True:
            # interação contínua com o servidor
            message = input("Digite uma mensagem para enviar (ou 'exit' para sair): ")
            if message.lower() == 'exit':
                break

            communicate_with_server(ssl_client_socket, message)

    finally:
        close_ssl_connection(ssl_client_socket)

if __name__ == "__main__":
    create_client()

